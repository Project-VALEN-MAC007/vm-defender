# TRAP Test Report — Round 8

Deploy fixes แล้ว จุดเว็บ B3/B4/B7 และ HTTPS session filter ผ่าน; Rabbit Hole/SSH/HTTP forward และ log sync ผ่าน. การแยก Honeypot VM / cowrie / web-honeypot ออกจาก Web จริงและ SSH Defender ไม่ผ่าน: ทั้ง 3 ต้นทางต่อ Web 22/23/8080 และ Defender 22 ได้. web-app บน internal network ต่อออกนอกไม่ได้. Dashboard 9090 ต่อไม่ได้เพราะ bind loopback. A6 เห็นฟอร์มใหม่และ login ด้วย TOTP เดิมได้ แต่ยังไม่ได้ทำการเปลี่ยน credential และ login ด้วยตัวใหม่ผ่าน UI; ต้องรับช่วงตามนโยบาย computer-use จึงไม่ลงผล PASS ทั้งขั้นตอน.

## เวลาและขอบเขต

Test-start UTC 2026-10-10T19:32:25.483006+00:00 (ไทย 11 ตุลาคม 2026 เวลา 02:32:25). Lab 3 VM เดิม SSH management 2221/2222/2223; credentials ไม่รวมในรายงาน. D0/D3 traffic จำลองผ่าน trap-attacker ไป 192.168.56.10 เท่านั้น ใช้ source IP ใหม่ตรวจประวัติก่อน test-start. D2 ใช้ TCP connect ธรรมดาและ UDP probe ตามพอร์ตที่ฟัง; Internet จำกัด 1.1.1.1:443 ตาม prompt รอบนี้ ไม่มีเทคนิคโจมตี/สแกน subnet. Host-only ตรวจ .10 และ .1 ซึ่งเป็นปลายทางจำกัด ไม่อ้างว่าครอบคลุมทุก 256 IP.
Log operational แยกรอบด้วย timestamp/start_time >= test-start; snapshot config/services บันทึกเวลารอบนี้. หน้าจอ TLS alert ใช้ retained history ของ Dashboard และไม่พบ fixture. [fresh-source-IP-audit.json](TRAP-Retest-Evidence/round8-20261010T193225Z/fresh-source-IP-audit.json) และ [source-unchanged-audit.json](TRAP-Retest-Evidence/round8-20261010T193225Z/source-unchanged-audit.json) ยืนยัน IP ใหม่และ source ไม่ถูกแก้โดยผู้ทดสอบ.
ย้าย report/Matrix/ZIP/SHA รอบ 7 ไป C:\Users\Yakult\Desktop\report\Previous-Reports\round7-before-round8-20261010T193225Z แล้ว SHA ทั้ง 4 ไฟล์ตรง; รายงานรอบก่อนและหลักฐาน FAIL ยังเก็บอยู่.

## Deploy / unit / baseline

อ่าน docker ps, services, ss -lntu และ config ก่อน deploy ทุก VM. สำรอง Web/Honeypot ใน /root/trap-round8-backup ตาม host evidence; backup มีข้อมูล runtime จึงไม่แจก tar ใน ZIP. Sync working tree รวม untracked ไป /opt/trap ทั้ง 3 VM; รักษา .env runtime และไม่ส่ง .git/cache/venv/node_modules. ตรวจ SHA manifest ทั้ง 3 เครื่องผ่านก่อน final build. Rebuild company app Real/Decoy และ web-honeypot, restart Dashboard. WordPress/DB เดิมและ container Real รอบ 7 เก็บแบบ stopped.
Defender unit 150/150; Web 150/150; Honey full run 150 tests มี 1 ERROR TimeoutError ระหว่าง /api/login/totp (149 ผ่าน); retest เฉพาะเคสเดียวผ่าน. เก็บ full FAIL และ retest log ไม่อ้างว่า Honey full run 150/150. หลักฐานไม่พอระบุสาเหตุของ timeout.
เก็บผลระหว่าง deployment ครบ: Web activation command timeout หลัง container เดิมหยุด จึงแยก rename/run และยืนยัน real/decoy 200 ภายหลัง. D0 ชุดแรกเริ่มก่อน activation เสร็จ พบ PHPSESSID จาก image เก่าและ login Real ไม่สำเร็จ จัดเป็น deployment-stage evidence; final cases ใช้ IP ใหม่และ images ที่ rebuild หลัง sync manifest ผ่าน. D3 exec-channel harness ปิด channel และหนึ่งรอบมี syntax error; เปลี่ยนเฉพาะเครื่องมือทดสอบเป็น PTY shell และเก็บ FAIL เดิมครบ ไม่แก้แอป.
ระหว่าง cleanupบัญชี shared test helper เขียน D0-final/cases.json เป็น empty RESULTS. กู้ case JSON 4 รายการจาก snapshot command/log ที่บันทึกไว้ก่อน cleanup โดยไม่เปลี่ยนผลหรือเวลา; เก็บไฟล์ว่างและ restoration SHA ไว้ใน host/harness-evidence-restoration.json.
ไฟล์ host/*-sync-tests.json, *-source-delivery-verified.json, *-build.json, *activate*, defender-real-decoy-check.json และ baseline.json เก็บ command/output. Docker อัปเดตกฎ NAT ตามการ replace container ตามปกติ; ไม่สั่งเพิ่ม/ลบ/แก้ firewall policy หรือ persistent config.

## D0 — รอบ 7 → รอบ 8

| ข้อ | รอบ 7 | รอบ 8 ผลจริง | ผล | หลักฐาน |
| --- | --- | --- | --- | --- |
| A3 HTTPS session | UI TLS ไม่พบ https session | dropdown HTTPS / TLS; UI หา IP .4 / Honeypot / Session พบ 1 session https, 4 actions, 0.1s | PASS | [screenshots/A3-HTTPS-session.png](TRAP-Retest-Evidence/round8-20261010T193225Z/screenshots/A3-HTTPS-session.png) |
| A3 TLS alert | ยังไม่ได้ยืนยัน alias บน alert จริง | raw eve TLS/HTTPS alerts ทั้ง retained และหลัง start =0; active rules เป็น 13 SSH/HTTP/Telnet ไม่มี TLS rule; UI Suricata + HTTPS/TLS ได้0ตรงกับ raw. ไม่เพิ่มกฎหรือแต่ง alert | NOT_TESTABLE: ไม่มี fixture | [host/A3-TLS-alert-fixture-audit.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/A3-TLS-alert-fixture-audit.json); [screenshots/A3-TLS-alert-no-fixture.png](TRAP-Retest-Evidence/round8-20261010T193225Z/screenshots/A3-TLS-alert-no-fixture.png) |
| A6 re-enroll UI | ฟอร์มซ่อนเมื่อเปิด TOTP | บัญชีชั่วคราวเปิด TOTP แล้ว login UI ด้วยของเดิม; My account แสดง password/current TOTP + ตั้งค่า Authenticator ใหม่. ไม่ยืนยัน credential ใหม่แทนผู้ใช้; ลบบัญชีหลังตรวจ | NOT_DONE full flow / PASS form | [screenshots/A6-form-visible.png](TRAP-Retest-Evidence/round8-20261010T193225Z/screenshots/A6-form-visible.png); [host/UI-temp-cleanup.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/UI-temp-cleanup.json) |
| B3 anonymous headers | Decoy เพิ่ม PHPSESSID | HTTP .3 / HTTPS .4 ไม่มี Set-Cookie PHPSESSID; home/robots header ทั้งชุดและลำดับเหมือน Real เมื่อไม่นับ Date | PASS | [defender/D0-final/cases.json](TRAP-Retest-Evidence/round8-20261010T193225Z/defender/D0-final/cases.json) |
| B4 robots | Real404 / Decoy200 bodyต่าง | HTTP+HTTPS ก่อน/หลังทั้งสองฝั่ง 200 body SHA เหมือนกัน | PASS | [defender/D0-final/cases.json](TRAP-Retest-Evidence/round8-20261010T193225Z/defender/D0-final/cases.json) |
| B7 Real alsid → decoy portal | 200 Sign in แทน portal | ส่ง cookie เดิม /portal หลัง redirect .5 ได้200 Customer portal, ข้อมูลปลอม Demo Customer ต่างจาก Acme Operations ของ Real; ไม่แลก session store ข้าม VM | PASS | [defender/D0-final/cases.json](TRAP-Retest-Evidence/round8-20261010T193225Z/defender/D0-final/cases.json) |
| Rabbit Hole + HTTP/HTTPS redirect | ทำงาน | /backup/ → config.json → /api/v1/users 200 ทั้ง3 มี node_id; Nginx real10.10.10.3:8080 → decoy10.10.10.2:8084 และ origin log | PASS | [defender/D0-final/cases.json](TRAP-Retest-Evidence/round8-20261010T193225Z/defender/D0-final/cases.json) |

A6 ไม่ถือเป็นบั๊กของฟอร์มรอบนี้: ข้อกำหนด browser computer-use ระบุ “Changing a password or other authentication credential” ต้องให้ผู้ใช้กรอก ยืนยัน และ submit credential ใหม่เอง. เตรียมฟอร์มและขอรับช่วงแล้ว ผู้ใช้ขอให้ทำอัตโนมัติ จึงยังยืนยัน end-to-end UI rotation ไม่ได้. ไม่ใช้ API แทนแล้วรายงานว่า UI ผ่าน. บัญชีทดสอบถูกลบ (HTTP200); trapadmin/trapuser เดิมคงอยู่.
### HTTP response ก่อน/หลัง — 192.168.56.3

| URL | Real status | Decoy status | Real ms | Decoy ms | Body SHA256 |
| --- | --- | --- | --- | --- | --- |
| / | 200 | 200 | 8.392 | 13.82 | 41a766fd0723dc7efe6ad370558227f617efc974e0a98938bb31ea9a46cfa055 (เหมือน=True) |
| /robots.txt | 200 | 200 | 6.878 | 6.887 | f357f66c1291128d90a2b41b70ecdeb59ecf78172b4c63a8e4b4b3171f9ac0ef (เหมือน=True) |

**Real home headers**

~~~http
HTTP/1.1 200 OK
Server: nginx/1.24.0 (Ubuntu)
Date: Sat, 10 Oct 2026 19:42:01 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 1263
Connection: keep-alive
~~~

**Decoy home headers**

~~~http
HTTP/1.1 200 OK
Server: nginx/1.24.0 (Ubuntu)
Date: Sat, 10 Oct 2026 19:42:01 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 1263
Connection: keep-alive
~~~

### HTTPS response ก่อน/หลัง — 192.168.56.4

| URL | Real status | Decoy status | Real ms | Decoy ms | Body SHA256 |
| --- | --- | --- | --- | --- | --- |
| / | 200 | 200 | 15.783 | 18.146 | 41a766fd0723dc7efe6ad370558227f617efc974e0a98938bb31ea9a46cfa055 (เหมือน=True) |
| /robots.txt | 200 | 200 | 19.293 | 15.361 | f357f66c1291128d90a2b41b70ecdeb59ecf78172b4c63a8e4b4b3171f9ac0ef (เหมือน=True) |

**Real home headers**

~~~http
HTTP/1.1 200 OK
Server: nginx/1.24.0 (Ubuntu)
Date: Sat, 10 Oct 2026 19:42:07 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 1263
Connection: keep-alive
~~~

**Decoy home headers**

~~~http
HTTP/1.1 200 OK
Server: nginx/1.24.0 (Ubuntu)
Date: Sat, 10 Oct 2026 19:42:07 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 1263
Connection: keep-alive
~~~

B7 response bodies/header/digest ฉบับจริงทั้งสองฝั่งอยู่ใน D0-final/cases.json และ .body/.headers. Body อาจต่างเพราะชื่อและข้อมูลปลอมตามที่ยอมรับใน prompt; cookie value ถูกปกปิดทั้งหมด.
ข้อจำกัดที่ยอมรับ: SSH host key, Telnet login:/NUL, SID2100492 ไม่วัดซ้ำรอบ8.

## ตารางพอร์ตเป้าหมาย — อ่านจาก config และ ss จริง

| เครื่อง/หมวด | IP ทดสอบ | Protocol/port | Bind ที่พบ |
| --- | --- | --- | --- |
| web | 10.10.10.3 | udp/53 | 127.0.0.54:53 |
| web | 10.10.10.3 | udp/68 | 10.0.2.15%enp0s3:68 |
| web | 10.10.10.3 | tcp/53 | 127.0.0.54:53 |
| web | 10.10.10.3 | tcp/45371 | 127.0.0.1:45371 |
| web | 10.10.10.3 | tcp/8080 | 10.10.10.3:8080 |
| web | 10.10.10.3 | tcp/23 | 0.0.0.0:23 |
| web | 10.10.10.3 | tcp/22 | 0.0.0.0:22 |
| defender | 10.10.10.1 | udp/53 | 127.0.0.54:53 |
| defender | 10.10.10.1 | udp/68 | 10.0.2.15%enp0s3:68 |
| defender | 10.10.10.1 | tcp/22 | 0.0.0.0:22 |
| defender | 10.10.10.1 | tcp/9090 | 127.0.0.1:9090 |
| defender | 10.10.10.1 | tcp/53 | 127.0.0.53%lo:53 |
| defender | 10.10.10.1 | tcp/443 | 192.168.56.10:443 |
| defender | 10.10.10.1 | tcp/80 | 192.168.56.10:80 |
| host-only | 192.168.56.10 | tcp/22 | explicit bounded reachability target |
| host-only | 192.168.56.10 | tcp/80 | explicit bounded reachability target |
| host-only | 192.168.56.10 | tcp/443 | explicit bounded reachability target |
| host-only | 192.168.56.10 | tcp/9090 | explicit bounded reachability target |
| host-only | 192.168.56.1 | tcp/22 | explicit bounded reachability target |
| host-only | 192.168.56.1 | tcp/80 | explicit bounded reachability target |
| host-only | 192.168.56.1 | tcp/443 | explicit bounded reachability target |
| internet | 1.1.1.1 | tcp/443 | explicit bounded reachability target |

Dashboard config dashboard.host=127.0.0.1 / port9090; Nginx bind192.168.56.10:80/443; SSH Def/Web/Honey0.0.0.0:22; Web Telnet23 และ trap-web10.10.10.3:8080. DNS53และ DHCP68/localhost containerd port เป็น listener ที่ scope ต่างจาก 10.10.10.x จึงบันทึก probe ที่ IP lab แต่ไม่ตีความ refusal ว่า firewall drop. UDP silence ไม่พิสูจน์ isolation.

## D1 — firewall / routing / container hardening

FAIL: ไม่พบ deny policy สำหรับ Honey10.10.10.2 → Web10.10.10.3 หรือ Defender10.10.10.1. Honey OUTPUT/INPUT ACCEPT; Docker DOCKER-USER ว่าง, default bridge มี MASQUERADE และ DOCKER-FORWARD accept traffic ออกจาก bridge. Web INPUT ACCEPT และ Docker published8080 DNAT/ACCEPT ไม่จำกัด source. Defender มี forward default drop เฉพาะการผ่านเครื่อง แต่ไม่มี input chain ที่ห้าม Honeyเข้าพอร์ต22; traffic Honey→Web เป็น neighbor บน internal subnet ไม่ผ่าน forward chain Defender.
เส้นทาง Honey host: lab10.10.10.0/24 ผ่าน enp0s8; 192.168.56.0/24 via10.10.10.1; default via10.0.2.2 enp0s3 (VirtualBox NAT). Cowrie/web-honeypot ใช้ default bridge gateway172.18.0.1 และ MASQUERADE ออก Honey host; web-honeypot ยังมี decoy network เพิ่ม. web-app อยู่ decoy172.19.0.0/16 internal=true ไม่มี default route/published port. รายละเอียดครบใน network inspect ก่อน/หลัง และ routes ของแต่ละ D2 origin.
Log sync ที่จำเป็นเป็น Defender → Honeypot management SSH22: Defender pull log ด้วย restricted key แล้ว install ใน /var/log/trap/honeypot, timer ทำงาน. ไม่ใช่ Honey → Defender push จึงไม่พบความจำเป็นให้ Honeyเริ่ม SSH22 ไป Defender. Cowrie decoy SSH2222/Telnet2223, web-honeypot8084 publishเฉพาะ10.10.10.2.
| Container | running | user | read_only | cap_drop | privileged | Networks | Published ports |
| --- | --- | --- | --- | --- | --- | --- | --- |
| /web-honeypot | True | 997:988 | True | ['ALL'] | False | trap-honeypot_decoy,trap-honeypot_default | {"8084/tcp": [{"HostIp": "10.10.10.2", "HostPort": "8084"}]} |
| /web-app | True | 10002 | True | ['ALL'] | False | trap-honeypot_decoy | {"8080/tcp": null} |
| /cowrie | True | 999:999 | False | ['ALL'] | False | trap-honeypot_default | {"2222/tcp": [{"HostIp": "10.10.10.2", "HostPort": "2222"}], "2223/tcp": [{"HostIp": "10.10.10.2", "HostPort": "2223"}]} |
| /trap-web | True | 10002 | False | None | False | bridge | {"8080/tcp": [{"HostIp": "10.10.10.3", "HostPort": "8080"}]} |
| /trap-web-round7-backup | False | 10002 | False | None | False | bridge | {} |
| /production-web-1 | False | (image default/root config) | False | None | False | production_default | {} |
| /production-db-1 | False | (image default/root config) | False | None | False | production_default | {} |

Honeypot 3 containers non-root, cap_drop ALL, privileged=false, no-new-privileges และไม่มี docker.sock mount. Cowrie read_only=false ไม่ผ่านข้อนี้. web-honeypot mount /var/lib/trap:ro ทั้ง directory และ /var/log/trap:rw ทั้ง directory เป็น scope กว้างเกินไฟล์ config/logที่ใช้; ไม่ใช่ root host mount แต่ควรจำกัดเป็นรายไฟล์/โฟลเดอร์ที่จำเป็น. Cowrie config/honeyfs mountro, logs/volumesrwตาม inspect. Real trap-web non-root10002 แต่ run configไม่มี read_only/cap_drop ตามตาราง; container WordPress/DB และ Realรอบ7ที่ stopped ก็ inspectครบและแยกสถานะไว้ ไม่อ้างว่า active.
หลักฐาน [host/honeypot-network-inspect-after.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/honeypot-network-inspect-after.json), [host/web-network-inspect-after.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/web-network-inspect-after.json), [host/defender-network-inspect-after.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/defender-network-inspect-after.json), [host/D1-honeypot-container-hardening.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/D1-honeypot-container-hardening.json).

## D2 — ต้นทาง × ปลายทาง × พอร์ต ครบทุกคู่ใน catalog

| ต้นทาง | ปลายทาง | Protocol/port | ผล socket | Error | seconds | ประเมิน |
| --- | --- | --- | --- | --- | --- | --- |
| Honeypot-VM | 10.10.10.3 | udp/53 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.004 | NOT_PROVEN (UDP) |
| Honeypot-VM | 10.10.10.3 | udp/68 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.008 | NOT_PROVEN (UDP) |
| Honeypot-VM | 10.10.10.3 | tcp/53 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 10.10.10.3 | tcp/45371 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 10.10.10.3 | tcp/8080 | CONNECTED |  | 0.002 | FAIL isolation |
| Honeypot-VM | 10.10.10.3 | tcp/23 | CONNECTED |  | 0.002 | FAIL isolation |
| Honeypot-VM | 10.10.10.3 | tcp/22 | CONNECTED |  | 0.001 | FAIL isolation |
| Honeypot-VM | 10.10.10.1 | udp/53 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.003 | NOT_PROVEN (UDP) |
| Honeypot-VM | 10.10.10.1 | udp/68 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.004 | NOT_PROVEN (UDP) |
| Honeypot-VM | 10.10.10.1 | tcp/22 | CONNECTED |  | 0.001 | FAIL isolation |
| Honeypot-VM | 10.10.10.1 | tcp/9090 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 10.10.10.1 | tcp/53 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 10.10.10.1 | tcp/443 | NOT_CONNECTED | ConnectionRefusedError | 0.002 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 10.10.10.1 | tcp/80 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 192.168.56.10 | tcp/22 | CONNECTED |  | 0.003 | ต่อได้ / observation |
| Honeypot-VM | 192.168.56.10 | tcp/80 | CONNECTED |  | 0.001 | ต่อได้ / observation |
| Honeypot-VM | 192.168.56.10 | tcp/443 | CONNECTED |  | 0.001 | ต่อได้ / observation |
| Honeypot-VM | 192.168.56.10 | tcp/9090 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 192.168.56.1 | tcp/22 | NOT_CONNECTED | TimeoutError | 3.004 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 192.168.56.1 | tcp/80 | NOT_CONNECTED | TimeoutError | 3.004 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 192.168.56.1 | tcp/443 | NOT_CONNECTED | TimeoutError | 3.004 | ต่อไม่ได้ ณ เวลาทดสอบ |
| Honeypot-VM | 1.1.1.1 | tcp/443 | CONNECTED |  | 0.013 | ต่อได้ / observation |
| cowrie | 10.10.10.3 | udp/53 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.012 | NOT_PROVEN (UDP) |
| cowrie | 10.10.10.3 | udp/68 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.013 | NOT_PROVEN (UDP) |
| cowrie | 10.10.10.3 | tcp/53 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 10.10.10.3 | tcp/45371 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 10.10.10.3 | tcp/8080 | CONNECTED |  | 0.001 | FAIL isolation |
| cowrie | 10.10.10.3 | tcp/23 | CONNECTED |  | 0.002 | FAIL isolation |
| cowrie | 10.10.10.3 | tcp/22 | CONNECTED |  | 0.002 | FAIL isolation |
| cowrie | 10.10.10.1 | udp/53 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.007 | NOT_PROVEN (UDP) |
| cowrie | 10.10.10.1 | udp/68 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.006 | NOT_PROVEN (UDP) |
| cowrie | 10.10.10.1 | tcp/22 | CONNECTED |  | 0.008 | FAIL isolation |
| cowrie | 10.10.10.1 | tcp/9090 | NOT_CONNECTED | ConnectionRefusedError | 0.002 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 10.10.10.1 | tcp/53 | NOT_CONNECTED | ConnectionRefusedError | 0.002 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 10.10.10.1 | tcp/443 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 10.10.10.1 | tcp/80 | NOT_CONNECTED | ConnectionRefusedError | 0.002 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 192.168.56.10 | tcp/22 | CONNECTED |  | 0.01 | ต่อได้ / observation |
| cowrie | 192.168.56.10 | tcp/80 | CONNECTED |  | 0.011 | ต่อได้ / observation |
| cowrie | 192.168.56.10 | tcp/443 | CONNECTED |  | 0.001 | ต่อได้ / observation |
| cowrie | 192.168.56.10 | tcp/9090 | NOT_CONNECTED | ConnectionRefusedError | 0.002 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 192.168.56.1 | tcp/22 | NOT_CONNECTED | TimeoutError | 3.003 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 192.168.56.1 | tcp/80 | NOT_CONNECTED | TimeoutError | 3.004 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 192.168.56.1 | tcp/443 | NOT_CONNECTED | TimeoutError | 3.004 | ต่อไม่ได้ ณ เวลาทดสอบ |
| cowrie | 1.1.1.1 | tcp/443 | CONNECTED |  | 0.015 | ต่อได้ / observation |
| web-honeypot | 10.10.10.3 | udp/53 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.003 | NOT_PROVEN (UDP) |
| web-honeypot | 10.10.10.3 | udp/68 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.005 | NOT_PROVEN (UDP) |
| web-honeypot | 10.10.10.3 | tcp/53 | NOT_CONNECTED | ConnectionRefusedError | 0.002 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 10.10.10.3 | tcp/45371 | NOT_CONNECTED | ConnectionRefusedError | 0.002 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 10.10.10.3 | tcp/8080 | CONNECTED |  | 0.002 | FAIL isolation |
| web-honeypot | 10.10.10.3 | tcp/23 | CONNECTED |  | 0.005 | FAIL isolation |
| web-honeypot | 10.10.10.3 | tcp/22 | CONNECTED |  | 0.002 | FAIL isolation |
| web-honeypot | 10.10.10.1 | udp/53 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.005 | NOT_PROVEN (UDP) |
| web-honeypot | 10.10.10.1 | udp/68 | NO_RESPONSE_UNCONFIRMED | TimeoutError | 3.005 | NOT_PROVEN (UDP) |
| web-honeypot | 10.10.10.1 | tcp/22 | CONNECTED |  | 0.001 | FAIL isolation |
| web-honeypot | 10.10.10.1 | tcp/9090 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 10.10.10.1 | tcp/53 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 10.10.10.1 | tcp/443 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 10.10.10.1 | tcp/80 | NOT_CONNECTED | ConnectionRefusedError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 192.168.56.10 | tcp/22 | CONNECTED |  | 0.004 | ต่อได้ / observation |
| web-honeypot | 192.168.56.10 | tcp/80 | CONNECTED |  | 0.001 | ต่อได้ / observation |
| web-honeypot | 192.168.56.10 | tcp/443 | CONNECTED |  | 0.001 | ต่อได้ / observation |
| web-honeypot | 192.168.56.10 | tcp/9090 | NOT_CONNECTED | ConnectionRefusedError | 0.002 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 192.168.56.1 | tcp/22 | NOT_CONNECTED | TimeoutError | 3.005 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 192.168.56.1 | tcp/80 | NOT_CONNECTED | TimeoutError | 3.003 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 192.168.56.1 | tcp/443 | NOT_CONNECTED | TimeoutError | 3.003 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-honeypot | 1.1.1.1 | tcp/443 | CONNECTED |  | 0.017 | ต่อได้ / observation |
| web-app | 10.10.10.3 | udp/53 | NOT_CONNECTED | OSError | 0.001 | NOT_PROVEN (UDP) |
| web-app | 10.10.10.3 | udp/68 | NOT_CONNECTED | OSError | 0.0 | NOT_PROVEN (UDP) |
| web-app | 10.10.10.3 | tcp/53 | NOT_CONNECTED | OSError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 10.10.10.3 | tcp/45371 | NOT_CONNECTED | OSError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 10.10.10.3 | tcp/8080 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 10.10.10.3 | tcp/23 | NOT_CONNECTED | OSError | 0.001 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 10.10.10.3 | tcp/22 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 10.10.10.1 | udp/53 | NOT_CONNECTED | OSError | 0.002 | NOT_PROVEN (UDP) |
| web-app | 10.10.10.1 | udp/68 | NOT_CONNECTED | OSError | 0.002 | NOT_PROVEN (UDP) |
| web-app | 10.10.10.1 | tcp/22 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 10.10.10.1 | tcp/9090 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 10.10.10.1 | tcp/53 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 10.10.10.1 | tcp/443 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 10.10.10.1 | tcp/80 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 192.168.56.10 | tcp/22 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 192.168.56.10 | tcp/80 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 192.168.56.10 | tcp/443 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 192.168.56.10 | tcp/9090 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 192.168.56.1 | tcp/22 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 192.168.56.1 | tcp/80 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 192.168.56.1 | tcp/443 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |
| web-app | 1.1.1.1 | tcp/443 | NOT_CONNECTED | OSError | 0.0 | ต่อไม่ได้ ณ เวลาทดสอบ |

คำสั่ง+Python socket payload อยู่ใน host/D2-<origin>.json; Pythonที่มีอยู่ใน image เท่านั้น ไม่ติดตั้งเครื่องมือเพิ่ม: cowrie /cowrie/cowrie-env/bin/python3, web-honeypot/web-app python3, Honey host python3. TCP timeout3s, probes4concurrent/origin, ปิดทันทีหลัง connect. UDP53ส่ง DNS queryสำหรับ example.invalid; UDP68ส่งempty datagram; ไม่มี response ให้ผล NOT_PROVEN. ไม่ใช้ nc -u success เป็นหลักฐานเปิด/ปิด.
ยืนยันระดับ HTTP จาก Honey host: curl -m5 http://10.10.10.3:8080/ ได้200หน้าAcme Logistics; curl Dashboard10.10.10.1:9090 ต่อไม่ได้. Exitcodeรวม7มาจากคำสั่งหลัง ไม่ใช่แปลว่าWeb8080ล้มเหลว. ดู [host/D2-HTTP-host.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/D2-HTTP-host.json).

## D3 — คำสั่ง download ใน Cowrie ผ่าน redirect จริง

IP 192.168.56.11; SSH redirect decision และ Cowrie login originยืนยัน. ใช้ native Paramiko PTY แล้วส่งคำสั่งแยกกัน:

| คำสั่ง | Outputจริง | seconds |
| --- | --- | --- |
| wget http://10.10.10.3:8080/ | wget http://10.10.10.3:8080/<br>ESC[4l--2026-10-10 19:45:53--  http://10.10.10.3:8080/<br>Resolving 10.10.10.3 (10.10.10.3)... failed: Temporary failure in name resolution.<br>wget: unable to resolve host address ‘10.10.10.3’<br>ESC[4hroot@project-web:~#  | 0.022172 |
| curl http://10.10.10.1:9090/ | curl http://10.10.10.1:9090/<br>ESC[4lcurl: (6) Could not resolve host: 10.10.10.1<br>ESC[4hroot@project-web:~#  | 0.014948 |

PASS สำหรับข้อสังเกตนี้: Cowrie command.input มีทั้ง wget/curl; packet capture ฝั่ง WebและDefenderช่วงทดสอบ filter source10.10.10.2+dest8080/9090 ได้0packets ทั้งคู่ ไม่มีrequestจากIPนี้ในcapture. จับก่อนส่งคำสั่งและตรวจtcpdump0drops/header-only24bytes. แต่สาเหตุการไม่มีrequestในCowrieเคสนี้เป็น download command ตอบ resolution error จึงไม่ใช่หลักฐานว่า firewall block. D2ใช้Pythonในcontainerยังต่อปลายทางที่ห้ามได้.
Web app log_message ปิด access logging; Dashboard journal/security auditไม่ได้เป็นHTTP access logครบทุกrequest จึงไม่อ้างว่า absenceจากlogเพียงอย่างเดียวพิสูจน์ไม่มีrequest. อ่าน journalทั้งสองฝั่งประกอบและใช้captureยืนยันtrafficช่วงนี้. หลักฐาน [defender/D3-pty-final/cases.json](TRAP-Retest-Evidence/round8-20261010T193225Z/defender/D3-pty-final/cases.json), [host/D3-web-capture-and-service-log.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/D3-web-capture-and-service-log.json), [host/D3-defender-capture-and-service-log.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/D3-defender-capture-and-service-log.json), [host/D3-web-capture-counts.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/D3-web-capture-counts.json). Raw pcapsอยู่privateบนVM ไม่รวมZIP; textoutputครบและไม่มีpayloadcredential.

## D4 — ทางที่ระบบต้องใช้

| เส้นทาง | ผลจริง | ผล | หลักฐาน |
| --- | --- | --- | --- |
| Defender→Cowrie SSH | D3 PTYเข้าCowrieหลังredirect; command.input logตรงIPใหม่ | PASS | [defender/D3-pty-final/cases.json](TRAP-Retest-Evidence/round8-20261010T193225Z/defender/D3-pty-final/cases.json) |
| Defender→web-honeypot HTTP | D0 HTTPและtrail upstream10.10.10.2:8084, HTTP200และoriginrequest | PASS | [defender/D0-final/cases.json](TRAP-Retest-Evidence/round8-20261010T193225Z/defender/D0-final/cases.json) |
| web-honeypot→web-app | docker exec Python urllib http://web-app:8080/ 200 Acme Logistics | PASS | [host/D4-forward-internal.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/D4-forward-internal.json) |
| Honeypot→Dashboard via pull sync | HTTPSsession.4เห็นUIและAPI, Cowrieoriginlogsync; trap-log-sync.timer active last-successปัจจุบัน | PASS | [screenshots/A3-HTTPS-session.png](TRAP-Retest-Evidence/round8-20261010T193225Z/screenshots/A3-HTTPS-session.png); [host/final-services.json](TRAP-Retest-Evidence/round8-20261010T193225Z/host/final-services.json) |

สรุป D0 PARTIAL (A6 full UI ไม่ได้ทำ; TLS alertไม่มีfixture), D1 FAIL, D2 FAIL, D3 PASS แบบขอบเขตcommandที่ทดสอบ, D4 PASS. การใช้งานredirectปกติยังทำงาน แต่ไม่ถือว่าisolatedlabมีการcontainHoneypotครบ.

## ข้อเสนอแก้ — ยังไม่ได้ลงมือ

1. วาง deny policy ออกจาก Honey VMสำหรับWebและพอร์ตจัดการDefender; trafficHoney→Webอยู่same subnetจึงต้อง enforceบนHoney OUTPUT/forwardและWeb INPUT/DOCKER-USER หรือแยกnetwork/VLAN ไม่พึ่งDefenderforwardchainเพียงอย่างเดียว. กฎต้องครอบคลุมpublishedDockerportsและMASQUERADE.
2. แยก management path ออกจาก decoy egress; allowเฉพาะDefenderinitiatedSSH22pull logs และtrafficresponseestablished รวมถึงDefender→Honey2222/2223/8084; ปิดcowrie/web-honeypot default-network outboundไปlab/Internetที่ไม่จำเป็น. คงweb-honeypot→web-app8080บนinternalnetwork.
3. เปิดread_onlyให้Cowrieพร้อมwritablemount/tmpfsเฉพาะpathที่imageใช้; ลดweb-honeypotbindmountให้แคบ. HardenRealcontainerเช่นเดียวกันโดยตรวจผลก่อนปรับ. ไม่มีการแก้hardeningในรอบนี้.
4. เพิ่มaccess loggingที่รองรับauditของWeb/Dashboardในงานแก้ภายหลัง และเตรียมTLSalertfixtureที่ถูกต้องเพื่อทดสอบfilterเต็มข้อ โดยไม่แต่งlogผลจริง.

## ไฟล์และข้อมูลลับ

ไม่แก้ implementation หรือ firewall config และไม่ commit. Baseline SHA auditผ่าน; syncเป็นโค้ดที่ผู้ใช้แก้ไว้ก่อนเริ่ม. ไฟล์artifactใหม่คือ report/Matrix/evidenceZIP/SHA; เครื่องมือทดสอบอยู่นอกrepo. ปกปิดpassword/TOTPsecret/cookievalue/APIkeyทั้งหมด ไม่รวม.env/private/sourcearchive/backupในZIP. เก็บFAILจริงและSUPERSEDEDของharnessแยกไว้. แหล่งlogสองฝั่ง: [Defender-eve.json](TRAP-Retest-Evidence/round8-20261010T193225Z/Defender-eve.json), [Defender-decisions.json](TRAP-Retest-Evidence/round8-20261010T193225Z/Defender-decisions.json), [Defender-nginx.json](TRAP-Retest-Evidence/round8-20261010T193225Z/Defender-nginx.json), [Honeypot-cowrie-origin.json](TRAP-Retest-Evidence/round8-20261010T193225Z/Honeypot-cowrie-origin.json), [Honeypot-web-origin.json](TRAP-Retest-Evidence/round8-20261010T193225Z/Honeypot-web-origin.json).
