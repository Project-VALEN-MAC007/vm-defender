# TRAP Test Report — Round 7

Deploy และวัดบน VM จริงครบตามรายการรอบ 7 โดยไม่แก้ implementation และไม่ commit. ผล deploy ผ่าน; unit test สุดท้าย 146/146 ทั้งสามเครื่อง; A2 ผ่าน; A3/A6 ยังไม่ผ่านบางขั้นตอนใน UI แม้ API ผ่าน; regression ET Open ผ่าน 12/13 โดย SID 2100492 ไม่พบข้อความ trigger จาก Telnet จริง. PASS ของส่วน B หมายถึงเก็บและยืนยันการวัดสำเร็จ ไม่ได้หมายความว่าผู้โจมตีจับ redirect ไม่ได้.

## ขอบเขต เวลา และหลักฐาน

Test-start UTC: 2026-10-10T18:56:54.762558+00:00 (ไทย 11 ตุลาคม 2026 เวลา 01:56:54). Traffic ทดสอบทั้งหมดผ่าน trap-attacker ไป 192.168.56.10 เท่านั้น. ใช้ IP ใหม่รายเคส; ภายในเคสใช้ IP เดิมก่อน/หลัง redirect. การตรวจ A2/A3 แบบ read-only ใช้ log ของเคสเดิม .229/.230 โดยไม่ยิงซ้ำ. [fresh-source-IP-audit.json](TRAP-Retest-Evidence/round7-20261010T185654Z/fresh-source-IP-audit.json) ยืนยันไม่มี IP เหล่านี้ในประวัติก่อน test-start.
RAM ว่างก่อนเริ่ม: host 2072.15625 MiB; Defender/Honeypot/Web MemAvailable 1520/1449/1340 MiB. ตรวจ NTP ทั้งสามเครื่อง synchronized และวัดด้วย RTT compensation: ต่างกันสูงสุด 0.05471205711364746 วินาที (<1 วินาที). Host clock มี offset ประมาณ 2.2 วินาที จึงใช้เวลา UTC ใน VM สำหรับหลักฐาน traffic.
ย้ายรายงานรอบ 6 ไป Previous-Reports/round6-before-round7-20261010T185654Z แล้วตรวจ SHA256 ทั้ง 4 ไฟล์ตรงกัน; ดู [host/archive.json](TRAP-Retest-Evidence/round7-20261010T185654Z/host/archive.json). รายงาน/หลักฐานรอบ 6 เดิมยังเก็บอยู่ ไม่รันทดสอบรอบ 1–6 ซ้ำ.
Log สองฝั่งกรอง timestamp/start_time >= test-start: [Defender-eve.json](TRAP-Retest-Evidence/round7-20261010T185654Z/Defender-eve.json), [Defender-decisions.json](TRAP-Retest-Evidence/round7-20261010T185654Z/Defender-decisions.json), [Defender-nginx.json](TRAP-Retest-Evidence/round7-20261010T185654Z/Defender-nginx.json), [Honeypot-cowrie-origin.json](TRAP-Retest-Evidence/round7-20261010T185654Z/Honeypot-cowrie-origin.json), [Honeypot-web-origin.json](TRAP-Retest-Evidence/round7-20261010T185654Z/Honeypot-web-origin.json). Case JSON บันทึก UTC, source IP, คำสั่ง, response และการเชื่อมโยง log. ภาพหน้าจอเป็นสถานะ UI ขณะตรวจ; ค่าสรุปบน Dashboard บางหน้าครอบคลุม retained history ตามช่วงหน้าจอ ไม่ใช่จำนวนเฉพาะรอบ 7.

## Deploy และการกู้สถานะ

| รายการ | ผลจริง | ผล |
| --- | --- | --- |
| สำรองก่อนเปลี่ยน | Web: production/WordPress compose + unit; Honeypot: compose, rabbit-hole.json, cowrie.cfg, unit และ honeyfs เพิ่มเติม. Backup อยู่ใน /root/trap-round7-backup บน VM สิทธิ์จำกัด ไม่รวมใน ZIP เพราะอาจมี secret. SHA อยู่ใน host evidence. | PASS |
| Sync working tree | ส่ง working tree รวม untracked ไป /opt/trap ทั้ง 3 VM; ไม่ส่ง .git/cache/.venv/node_modules/.env และเก็บ .env runtime เดิม. ตรวจ SHA ทุกไฟล์ที่ส่งใน *-source-delivery-verified.json ไม่มี mismatch. | PASS |
| Unit test | Defender 146/146; Honeypot final 146/146; Web 146/146. Honey run แรก 138 ผ่าน/8 fail ระหว่าง source delivery ซ้อนกัน เก็บไว้และ superseded หลังตรวจ manifest/รันซ้ำ; ไม่จัดเป็นบั๊ก runtime. | PASS final |
| Project-Web | สร้าง trap/web-app:local; trap-web BACKEND=real bind 10.10.10.3:8080; curl จาก Defender 200 Acme Logistics; real/default upstream ยัง 10.10.10.3:8080. WordPress/MariaDB เดิมหยุดและเก็บ volume. | PASS |
| Decoy + forward | cowrie, web-honeypot, web-app running; web-app BACKEND=decoy ไม่มี published port บน internal decoy network ไม่มี gateway/default route. ยืนยันด้วย inspect และ /proc/net/route ไม่ส่ง ping ออกนอก lab. ตั้ง web.upstream=http://web-app:8080, host=0.0.0.0, trusted_proxies=10.10.10.1/32 ทั้ง config ต้นทาง Defender และ Honey. | PASS |
| Cowrie identity | อ่านเครื่องจริง: project-web, OpenSSH_9.6p1 Ubuntu-3ubuntu13.19, Linux 6.8.0-142-generic. ตั้ง hostname/version, shell.kernel_version และ honeyfs/etc/issue.net ตามค่าจริง. ใช้ supported runtime data/config; ไม่ patch Cowrie code. | PASS / prompt limitation |
| Dashboard deploy | หลัง restart พบ PermissionError: /etc/trap เป็น root:root 0700 ตั้งมาก่อน test-start. ปรับ runtime directory เป็น root:trap-dashboard 0710 ให้ service traverse ได้; secret files ยังจำกัดสิทธิ์. service active/API 200. ไม่แก้โค้ด. | PASS |
| คืนค่า | ลบบัญชีทดสอบหลังเปลี่ยน TOTP; trapadmin/trapuser password/secret เดิมตรงกันและ roles เดิม; threshold 15/40 ไม่เปลี่ยน. Services/containers ทำงานตาม final state evidence. | PASS |

หลักฐาน deploy/unit/backup อยู่ใน host/; state และ journal อยู่ใน [Defender-service-and-deploy-evidence.json](TRAP-Retest-Evidence/round7-20261010T185654Z/Defender-service-and-deploy-evidence.json), [Honeypot-state.json](TRAP-Retest-Evidence/round7-20261010T185654Z/Honeypot-state.json), [Web-origin.json](TRAP-Retest-Evidence/round7-20261010T185654Z/Web-origin.json). Web app ปิด access logging ใน log_message จึงไม่มีราย request ใน Docker stdout; ใช้ response/body digest + Defender upstream trace ยืนยัน Real และ log ต้นทาง Honeypot ยืนยัน decoy โดยไม่อ้างว่ามี Real access log ที่ระบบไม่ได้สร้าง.

## Dashboard fixes A2 / A3 / A6

| ฟีเจอร์ | คาดหวัง | ผลจริง | ผล | หลักฐาน |
| --- | --- | --- | --- | --- |
| A2 | หน้าเว็บทั่วไปต้องเกิด session และ dwell ไม่ null ใน Alerts/Reports | HTTP .229 และ HTTPS .230 เปิด /, /about, /services เท่านั้น; มี session 3 actions และ dwell ไม่ null; Alerts แสดง 0.7s ทั้งสอง IP, Reports มีค่าเฉลี่ย rabbithole. HTTP API dwell 0.661928s. | PASS | [defender/dashboard-observation/cases.json](TRAP-Retest-Evidence/round7-20261010T185654Z/defender/dashboard-observation/cases.json); [screenshots/A2-alerts-dwell.png](TRAP-Retest-Evidence/round7-20261010T185654Z/screenshots/A2-alerts-dwell.png); [screenshots/A2-report-dwell.png](TRAP-Retest-Evidence/round7-20261010T185654Z/screenshots/A2-report-dwell.png) |
| A3 | filter HTTP/HTTPS หา Web Honeypot session | HTTP UI ได้ 1 session; API protocol=https ได้ 1 session. UI ไม่มีตัวเลือก HTTPS มี TLS ซึ่งส่ง protocol=tls แล้วได้ 0 เพราะ session จริงเป็น https และ filter เปรียบเทียบตรงตัว. | FAIL UI HTTPS / PASS HTTP+API | [host/A3-UI-HTTPS-observed.json](TRAP-Retest-Evidence/round7-20261010T185654Z/host/A3-UI-HTTPS-observed.json); [screenshots/A3-HTTP-session.png](TRAP-Retest-Evidence/round7-20261010T185654Z/screenshots/A3-HTTP-session.png); [screenshots/A3-TLS-filter-empty.png](TRAP-Retest-Evidence/round7-20261010T185654Z/screenshots/A3-TLS-filter-empty.png) |
| A6 | บัญชีที่เปิด TOTP แล้วตั้ง Authenticator ใหม่ผ่าน My account ด้วย password + current TOTP | หน้าบัญชีแสดงเปิดใช้ TOTP แล้ว แต่ซ่อน totp-setup-form จึงเริ่มขั้นตอน UI ไม่ได้. ทดสอบ endpoint setup/confirm ผ่าน: เปลี่ยน secret, session เดิม 401, code เดิม 401, code ใหม่ login 200 และ API 200. ทดสอบบนบัญชีชั่วคราวแล้วลบ; บัญชีเดิมไม่เปลี่ยน. | FAIL UI / PASS API | [host/A6-UI-hidden-evidence.json](TRAP-Retest-Evidence/round7-20261010T185654Z/host/A6-UI-hidden-evidence.json); [defender/dashboard/cases.json](TRAP-Retest-Evidence/round7-20261010T185654Z/defender/dashboard/cases.json); [screenshots/A6-my-account-form-hidden.png](TRAP-Retest-Evidence/round7-20261010T185654Z/screenshots/A6-my-account-form-hidden.png) |

สาเหตุที่พิสูจน์ได้: dashboard.js showApp ซ่อน form เมื่อ user.totp_enabled=true; A3 dropdown เลือก tls แต่ session protocol=https ไม่มี alias. ไม่แก้ implementation. FAIL ของ harness เดิม A2/A3 เก็บครบ: ครั้งแรกอ่าน list เป็น items; ครั้งถัดไปใช้ legacy notifications endpoint ซึ่งไม่ใช่ Alerts events. ตรวจซ้ำด้วย /api/events.json และ UI จริงผ่าน A2. Matrix ระบุ SUPERSEDED เฉพาะ harness เหล่านี้ แยกจาก UI FAIL จริง.

## ความเนียน: รอบ 6 → รอบ 7

| ข้อ / สิ่งที่ผู้โจมตีเห็น | รอบ 6 | Real รอบ 7 | Honeypot รอบ 7 | ต่าง / จับ redirect ได้ไหม |
| --- | --- | --- | --- | --- |
| B1 SSH host key | ต่าง / client เตือน | SHA256:Lkw42CWhaXZdwCBipAUvWkiXQiE/YS1NsFi6DYNyPCY | SHA256:YuVWrEbavoFeNEA0EeDQ2xRr1yoRXYC/PTZ97oKGUC4 | ต่าง; native OpenSSH REMOTE HOST IDENTIFICATION HAS CHANGED, exit 255. ข้อจำกัดที่ยอมรับยังอยู่ |
| B2 SSH version | OpenSSH vs Cowrie version ต่าง | SSH-2.0-OpenSSH_9.6p1 Ubuntu-3ubuntu13.19 | SSH-2.0-OpenSSH_9.6p1 Ubuntu-3ubuntu13.19 | เหมือน; เนียนขึ้นจาก version แต่ host key ยังต่าง |
| B2 Telnet | hostname/kernel/banner ต่าง | Linux 6.8.0-142-generic (project-web) (pts/0); project-web login: | Linux 6.8.0-142-generic (project-web) (pts/0); login: | banner ตรงขึ้น; prompt/NUL framing ยังต่าง จับได้ |
| B3 headers/cookie | WordPress/PHP headers vs maintenance ต่าง | Server nginx/1.24.0 (Ubuntu); anonymous ไม่มี cookie | Server ตรงกัน; request แรกเพิ่ม PHPSESSID | ชุด header ใกล้กันขึ้น แต่ cookie/ลำดับเพิ่มยังจับได้ |
| B4 body/URL | WordPress vs Acme maintenance ต่างชัด | Acme Logistics company app | โค้ดเดียวกัน public pages | 7 required paths × 2 protocols =14/14 body SHA/status เหมือน; รวม favicon 16/18; robots.txt ยังต่าง |
| B5 TLS cert | เหมือน | SHA256 495160a2507efe3773e51ebf5b7ff77fa1b6dad50fe36ce7b07df941843416d7 | fingerprint เดียวกัน TLSv1.3 | เหมือน; จับจาก cert ไม่ได้ในการทดสอบนี้ |
| B6 HTTP latency | median gap 92.7525ms | median 5.666ms | median 8.8225ms | gap 3.1565ms น้อยลง; timing ไม่ยืนยันว่าใช้งานจริงจับได้แน่นอน |
| B6 HTTPS latency | median gap 91.981ms | median 12.540ms | median 14.983ms | gap 2.443ms น้อยลง; outlier 219.302ms ยังเก็บไว้ |
| B7 authenticated web | session ใช้ต่อไม่ได้ / page ต่าง | /portal 200 Customer portal, 1111 bytes | ส่ง alsid เดิม /portal ได้ 200 Sign in, 1019 bytes | ยังจับได้จาก session หาย; หน้า login สอดคล้องกันขึ้น |
| B7 held SSH | ช่องเดิม Real / connection ใหม่ Cowrie | ช่องเดิม project-web/kali | ช่องเดิมยัง Real; connection ใหม่ Cowrie key | connection เดิมไม่ย้าย; ใหม่ยังตรวจจาก key ได้ |

### Response จริงและเวลา

#### HTTP — 192.168.56.219

| URL | Real status/bytes | Honeypot status/bytes | Real ms | Honeypot ms | body SHA เหมือน |
| --- | --- | --- | --- | --- | --- |
| / | 200/1263 | 200/1263 | 8.359 | 52.778 | True |
| /about | 200/939 | 200/939 | 7.193 | 12.417 | True |
| /services | 200/1117 | 200/1117 | 4.612 | 20.029 | True |
| /news | 200/1031 | 200/1031 | 6.99 | 10.987 | True |
| /login | 200/1019 | 200/1019 | 8.029 | 10.538 | True |
| /round7-missing-page | 404/750 | 404/750 | 5.9 | 8.829 | True |
| /static/site.css | 200/1863 | 200/1863 | 6.847 | 12.043 | True |
| /robots.txt | 404/750 | 200/73 | 6.747 | 12.974 | False |
| /favicon.ico | 404/750 | 404/750 | 10.655 | 7.965 | True |

Home response headers ตามลำดับที่ได้รับ (cookie value ปกปิด; body ฉบับเต็มและ SHA ใน [defender/partB/cases.json](TRAP-Retest-Evidence/round7-20261010T185654Z/defender/partB/cases.json)):

**Real**

~~~http
HTTP/1.1 200 OK
Server: nginx/1.24.0 (Ubuntu)
Date: Sat, 10 Oct 2026 19:03:15 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 1263
Connection: keep-alive
~~~

**Honeypot**

~~~http
HTTP/1.1 200 OK
Server: nginx/1.24.0 (Ubuntu)
Date: Sat, 10 Oct 2026 19:03:15 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 1263
Connection: keep-alive
Set-Cookie: PHPSESSID=[REDACTED]; Path=/; HttpOnly
~~~

#### HTTPS — 192.168.56.220

| URL | Real status/bytes | Honeypot status/bytes | Real ms | Honeypot ms | body SHA เหมือน |
| --- | --- | --- | --- | --- | --- |
| / | 200/1263 | 200/1263 | 15.953 | 18.454 | True |
| /about | 200/939 | 200/939 | 14.822 | 16.87 | True |
| /services | 200/1117 | 200/1117 | 15.014 | 17.029 | True |
| /news | 200/1031 | 200/1031 | 9.62 | 18.411 | True |
| /login | 200/1019 | 200/1019 | 10.864 | 20.227 | True |
| /round7-missing-page | 404/750 | 404/750 | 73.361 | 15.561 | True |
| /static/site.css | 200/1863 | 200/1863 | 10.022 | 12.509 | True |
| /robots.txt | 404/750 | 200/73 | 12.05 | 12.698 | False |
| /favicon.ico | 404/750 | 404/750 | 10.087 | 22.624 | True |

Home response headers ตามลำดับที่ได้รับ (cookie value ปกปิด; body ฉบับเต็มและ SHA ใน [defender/partB/cases.json](TRAP-Retest-Evidence/round7-20261010T185654Z/defender/partB/cases.json)):

**Real**

~~~http
HTTP/1.1 200 OK
Server: nginx/1.24.0 (Ubuntu)
Date: Sat, 10 Oct 2026 19:03:19 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 1263
Connection: keep-alive
~~~

**Honeypot**

~~~http
HTTP/1.1 200 OK
Server: nginx/1.24.0 (Ubuntu)
Date: Sat, 10 Oct 2026 19:03:19 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 1263
Connection: keep-alive
Set-Cookie: PHPSESSID=[REDACTED]; Path=/; HttpOnly
~~~

B1 SSH handshake Real 34.454ms / Cowrie 50.623ms. Fingerprints/banner และ native warning อยู่ใน [defender/partB/cases.json](TRAP-Retest-Evidence/round7-20261010T185654Z/defender/partB/cases.json).
Telnet raw response และเวลาทั้งสองฝั่ง (NUL แสดงเป็น escaped string):

~~~json
{
  "banner": "Trying 192.168.56.10...\r\nConnected to 192.168.56.10.\r\nEscape character is '^]'.\r\n\u0000\u0000\r\nLinux 6.8.0-142-generic (project-web) (pts/0)\r\n\r\nproject-web login: ",
  "reply": "",
  "elapsed_seconds": 0.06918843499806826
}
~~~

~~~json
{
  "banner": "Trying 192.168.56.10...\r\nConnected to 192.168.56.10.\r\nEscape character is '^]'.\r\n\r\nLinux 6.8.0-142-generic (project-web) (pts/0)\r\n\r\nlogin: ",
  "reply": "",
  "elapsed_seconds": 0.012359155000012834
}
~~~

Telnet prompt ของ image ปัจจุบันกำหนด login: ใน cowrie/telnet/userauth.py; การตั้ง supported hostname/kernel/issue.net ทำให้บรรทัด banner ตรง แต่ไม่ทำให้ prompt นี้เปลี่ยน. ไม่แก้ code.
TLS และเวลาจับมือทั้งสองฝั่ง: [defender/timing-extra/cases.json](TRAP-Retest-Evidence/round7-20261010T185654Z/defender/timing-extra/cases.json). บทสนทนา SSH ที่ค้างและเวลาคำสั่ง before/after อยู่ในไฟล์เดียวกัน. Web session เก็บ response body/header ทั้งสองฝั่งใน partB/cases.json: ส่ง cookie alsid เดิมแล้ว login HTML แทน portal; client ได้ HTTP 200 เพราะ Rabbit Hole forward ตาม upstream redirect ภายใน ไม่ได้เห็น HTTP 303 โดยตรง.
| การวัด | Real ก่อน | หลัง redirect | หลักฐานที่ client เห็น |
| --- | --- | --- | --- |
| B5 TLS handshake | 8.776 ms | 7.882 ms | TLSv1.3 / SHA256 certificate เดียวกัน |
| B7 web portal | 200 / Customer portal / 1111 bytes / 6.739 ms | 200 / Sign in / 1019 bytes / 13.002 ms | cookie เดิมถูกส่ง แต่ session ไม่ข้าม backend |
| B7 held SSH command | project-web + kali / 1015.637 ms | project-web + kali / 15.997 ms | transport เดิมยัง active; connection ใหม่ host key Cowrie |


### Latency: 20 requests ต่อฝั่งต่อ protocol

HTTP first request หลังเห็น decision โดยไม่มี sleep: 0.017714s; transition/decision/nginx readiness: {"trigger": {"time": "2026-10-10T19:03:33.379680+00:00", "command": "ip netns exec trap-attacker curl --interface 192.168.56.222 -skS -i --max-time 5 http://192.168.56.10/.htpasswd", "exit_code": 0, "stdout": "HTTP/1.1 404 Not Found\nServer: nginx/1.24.0 (Ubuntu)\nDate: Sat, 10 Oct 2026 19:03:33 GMT\nContent-Type: text/html; charset=utf-8\nContent-Length: 750\nConnection: keep-alive\n\n<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>Not found · Acme Logistics</title>\n<link rel=\"stylesheet\" href=\"/static/site.css\">\n</head>\n<body>\n<header class=\"site-header\"><div class=\"wrap\"><a class=\"brand\" href=\"/\">Acme Logistics</a><nav><a href=\"/\">Home</a><a href=\"/about\">About</a><a href=\"/services\">Services</a><a href=\"/news\">News</a><a href=\"/contact\">Contact</a><a href=\"/login\">Sign in</a></nav></div></header>\n<main class=\"wrap\">\n<h1>Page not found</h1><p>The page you requested does not exist.</p>\n</main>\n<footer class=\"site-footer\"><div class=\"wrap\">&copy; 2026 Acme Logistics Co., Ltd. · All rights reserved.</div></footer>\n</body>\n</html>\n", "stderr": ""}, "decision": {"action": "redirect_web", "adapter_result": "# generated atomically; do not edit\ndefault real;\n192.168.56.219 rabbithole;\n192.168.56.220 rabbithole;\n192.168.56.221 rabbithole;\n192.168.56.222 rabbithole;\n", "dry_run": false, "event_id": "11ca55bac113acc094acb02066c903919730418d33d5d6da8559b3af25b0c7af", "expiry": "2026-10-10T19:05:33.425570+00:00", "nginx_ready": true, "nginx_ready_seconds": 0.204, "profile": "rabbithole", "protocol": "http", "reason": "severity=1:+35;protocol=http:+5", "risk_score": 40.0, "severity": 1, "signature_id": 2101071, "source_ip": "192.168.56.222", "start_time": "2026-10-10T19:03:33.425570+00:00"}, "decision_seen": "2026-10-10T19:03:33.666852+00:00"}.
HTTPS first request หลังเห็น decision โดยไม่มี sleep: 0.01859s; transition/decision/nginx readiness: {"trigger": {"time": "2026-10-10T19:03:37.611260+00:00", "command": "ip netns exec trap-attacker curl --interface 192.168.56.223 -skS -i --max-time 5 http://192.168.56.10/.htpasswd", "exit_code": 0, "stdout": "HTTP/1.1 404 Not Found\nServer: nginx/1.24.0 (Ubuntu)\nDate: Sat, 10 Oct 2026 19:03:37 GMT\nContent-Type: text/html; charset=utf-8\nContent-Length: 750\nConnection: keep-alive\n\n<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>Not found · Acme Logistics</title>\n<link rel=\"stylesheet\" href=\"/static/site.css\">\n</head>\n<body>\n<header class=\"site-header\"><div class=\"wrap\"><a class=\"brand\" href=\"/\">Acme Logistics</a><nav><a href=\"/\">Home</a><a href=\"/about\">About</a><a href=\"/services\">Services</a><a href=\"/news\">News</a><a href=\"/contact\">Contact</a><a href=\"/login\">Sign in</a></nav></div></header>\n<main class=\"wrap\">\n<h1>Page not found</h1><p>The page you requested does not exist.</p>\n</main>\n<footer class=\"site-footer\"><div class=\"wrap\">&copy; 2026 Acme Logistics Co., Ltd. · All rights reserved.</div></footer>\n</body>\n</html>\n", "stderr": ""}, "decision": {"action": "redirect_web", "adapter_result": "# generated atomically; do not edit\ndefault real;\n192.168.56.219 rabbithole;\n192.168.56.220 rabbithole;\n192.168.56.221 rabbithole;\n192.168.56.222 rabbithole;\n192.168.56.223 rabbithole;\n", "dry_run": false, "event_id": "8d2a8179d195f22f5eabbc36915782d572025bed73c303cb867d8d648907f033", "expiry": "2026-10-10T19:05:37.737971+00:00", "nginx_ready": true, "nginx_ready_seconds": 0.166, "profile": "rabbithole", "protocol": "http", "reason": "severity=1:+35;protocol=http:+5", "risk_score": 40.0, "severity": 1, "signature_id": 2101071, "source_ip": "192.168.56.223", "start_time": "2026-10-10T19:03:37.737971+00:00"}, "decision_seen": "2026-10-10T19:03:37.936153+00:00"}.
| Protocol | Backend | n | min ms | median ms | mean ms | p95 ms | max ms |
| --- | --- | --- | --- | --- | --- | --- | --- |
| HTTP | Real | 20 | 4.216 | 5.666 | 5.523 | 6.034 | 6.693 |
| HTTP | Honeypot | 20 | 6.826 | 8.822 | 11.125 | 17.714 | 40.675 |
| HTTPS | Real | 20 | 9.725 | 12.54 | 15.344 | 32.567 | 46.757 |
| HTTPS | Honeypot | 20 | 12.106 | 14.983 | 25.358 | 18.783 | 219.302 |

วิธี: request แยก TCP/TLS ด้วย curl; time_total รวม transfer; trigger /.htpasswd แล้วอ่าน decision และส่ง follow-up ทันที. nginx_ready=true ใน transition ที่วัด. เก็บ HTTPS outlier 219.302ms โดยไม่มีหลักฐาน worker PID/trace เพียงพอให้ระบุว่าเกิดจาก reload. รอบ 6 เป็น WordPress ขนาดหน้าและ workload ต่างกัน จึงไม่อ้างว่าความต่างของ median ทั้งหมดมาจาก forward อย่างเดียว หรือว่าความต่างระดับนี้ผู้โจมตีทุกคนสังเกตได้.

### จุดที่ยังจับ redirect ได้ เรียงตามความง่ายในการสังเกต

1. SSH host key: client แสดง warning และหยุดเชื่อมต่อโดยตรง.
2. เว็บที่ login แล้ว: cookie เดิมไม่ให้ portal เดิม ได้หน้า Sign in แทน.
3. Telnet prompt/NUL framing: project-web login: เปลี่ยนเป็น login:.
4. Anonymous cookie PHPSESSID และ /robots.txt: Real 404 แต่ decoy 200 มี Disallow เส้นทางลวง.
5. Timing: median gap น้อยลงมาก แต่ยังมี outlier; เป็นสิ่งวัดได้ ไม่ใช่หลักฐานว่าทุก client จับได้.

SSH version, TLS certificate และ public body ของ 7 required paths ตรงกันในการวัดนี้. ไม่ได้ทดสอบความเท่ากันของทุก URL หรือทุกพฤติกรรมแอป.

## Regression สั้น และ Rabbit Hole

| Case | SID | IP | Decision ที่พบ | ผล |
| --- | --- | --- | --- | --- |
| ET-sqlmap | 2008538 | 192.168.56.231 | redirect_web | PASS |
| ET-Nikto | 2002677 | 192.168.56.232 | redirect_web | PASS |
| ET-Nmap | 2009359 | 192.168.56.233 | redirect_web | PASS |
| ET-Masscan | 2017616 | 192.168.56.234 | monitor | PASS |
| ET-UNION-URI | 2006446 | 192.168.56.235 | redirect_web | PASS |
| ET-UNION-body | 2053468 | 192.168.56.236 | redirect_web | PASS |
| ET-passwd | 2049400 | 192.168.56.237 | monitor | PASS |
| ET-env | 2031502 | 192.168.56.238 | monitor | PASS |
| ET-htpasswd | 2101071 | 192.168.56.239 | redirect_web | PASS |
| ET-SSH-scan | 2001219 | 192.168.56.240 | monitor | PASS |
| ET-LibSSH | 2006546 | 192.168.56.241 | redirect_ssh | PASS |
| ET-Telnet-Login-incorrect | 2101251 | 192.168.56.242 | monitor | PASS |
| ET-Telnet-Login-failed | 2100492 | 192.168.56.243 | ไม่พบ expected SID/decision | FAIL |

SID 2017616 Masscan ทุก decision เป็น monitor และมี scan_only_policy:monitor. SSH/Telnet single alert บางกฎเป็น monitor ตาม threshold 15/40; redirect จริงของ SSH/Telnet ยืนยันจาก B1/B2 พร้อม Cowrie-origin log. HTTP/HTTPS trace ยืนยัน upstream 10.10.10.2:8084 หลัง redirect และ 10.10.10.3:8080 ก่อน redirect.
FAIL SID 2100492: native Telnet real .243 ลอง login ผิด 3 ครั้งแล้วตอบ Login incorrect ทั้งสามครั้ง ไม่มี Login failed. Active rule 2100492 จับ content Login failed จึงไม่มี alert/decision ของ SID นี้; SID 2101251 จับ Login incorrect มีผลตามจริง. Cowrie ก็ใช้ Login incorrect. หลักฐาน [defender/regression/2100492-observed.json](TRAP-Retest-Evidence/round7-20261010T185654Z/defender/regression/2100492-observed.json) และ filtered eve/decisions; ไม่สรุปว่า Suricata parser เสีย ไม่เปลี่ยน telnetd และไม่ใช้ synthetic response เพื่อทำให้ผ่าน.
Rabbit Hole: /backup/ → /backup/config.json → /api/v1/users ได้ 200 และ log node_id; /.env และ /.htpasswd เก็บผล response/SID จริง; หน้า /about forward ไป app และ node_id ว่าง. ราย request, status และ node_id อยู่ใน [defender/regression/cases.json](TRAP-Retest-Evidence/round7-20261010T185654Z/defender/regression/cases.json) และ [Honeypot-web-origin.json](TRAP-Retest-Evidence/round7-20261010T185654Z/Honeypot-web-origin.json). ค่า API key/decoy config ที่คล้าย secret ถูกปกปิดใน bundle.
| Rabbit Hole URL | HTTP status | เวลา ms | node_id ที่ต้นทาง Honeypot |
| --- | --- | --- | --- |
| /backup/ | 200 | 29.025 | backup-index |
| /backup/config.json | 200 | 7.675 | backup-config |
| /.env | 200 | 8.531 | env |
| /.htpasswd | 404 | 10.156 | None |
| /about | 200 | 9.021 | None |

/.htpasswd ในรอบนี้ได้ 404 จาก forward path แต่ Suricata SID 2101071 ยังแจ้งเตือนจาก request URI; /.env ได้ 200 เส้นทางลวง. API /api/v1/users ผลต้นทาง 200 เก็บใน origin และ command response ของเคสเดียวกัน.

## สถานะไฟล์และข้อจำกัด

ไม่แก้ไฟล์ implementation ใน repo และไม่ commit. [source-unchanged-audit.json](TRAP-Retest-Evidence/round7-20261010T185654Z/source-unchanged-audit.json) ตรวจ baseline 352 ไฟล์: changed=[] / missing=[] / pass=true. ไฟล์ใหม่จากงานนี้เป็นรายงาน, Matrix, evidence ZIP/SHA และเครื่องมือทดสอบนอก repo. การเปลี่ยนบน VM เป็น deployment/runtime config, container และ directory permission ตามรายการข้างต้น. เก็บ FAIL ทุกครั้ง รวม unit/harness ระหว่างขั้นตอนและ case ที่ยัง FAIL; ไม่มีการลบหรือแทนผลให้เป็น PASS.
Original accounts คืนสภาพเดิม: [host/original-accounts-final.json](TRAP-Retest-Evidence/round7-20261010T185654Z/host/original-accounts-final.json). ไม่รวม password, TOTP secret, .env, private backup tar, session cookie value หรือ private API keys ในรายงาน/ZIP. หลักฐานที่ redacted อาจมี body bytes ต่างจาก digest ของ response ดั้งเดิม; public company bodies ที่ไม่ redacted เก็บ bytes จริง. SHA manifest และ ZIP checksum ยืนยันไฟล์ที่ส่งมอบ.
